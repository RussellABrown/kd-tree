#! /bin/bash
# Edit Constants.time java so that NLOGN = true, ENABLE_PREFERRED_NODE = true, ENABLE_1TO3 = true, ENABLE_INSERTION_REBALANCE = true, ENABLE_DELETION_REBALANCE = true, ENABLE_TUPLE_COPY = false, MULTI_THREAD_CUTOFF=16384
time java TestKdTreeDynamic -d 3 -n 526172 -b -i 100 > ./test/dynamic/526k/m4.526k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time java TestKdTreeDynamic -d 3 -n 1003201 -b -i 100 > ./test/dynamic/1003k/m4.1003k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time java TestKdTreeDynamic -d 3 -n 1464689 -b -i 100 > ./test/dynamic/1465k/m4.1465k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time java TestKdTreeDynamic -d 3 -n 1916615 -b -i 100 > ./test/dynamic/1917k/m4.1917k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time java TestKdTreeDynamic -d 3 -n 2361679 -b -i 100 > ./test/dynamic/2362k/m4.2362k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time java TestKdTreeDynamic -d 3 -n 2801418 -b -i 100 > ./test/dynamic/2801k/m4.2801k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time java TestKdTreeDynamic -d 3 -n 3236823 -b -i 100 > ./test/dynamic/3237k/m4.3237k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time java TestKdTreeDynamic -d 3 -n 3668582 -b -i 100 > ./test/dynamic/3669k/m4.3669k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time java TestKdTreeDynamic -d 3 -n 4097202 -b -i 100 > ./test/dynamic/4097k/m4.4097k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time java TestKdTreeDynamic -d 3 -n 4523071 -b -i 100 > ./test/dynamic/4523k/m4.4523k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
