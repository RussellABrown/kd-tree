#! /bin/bash
# Edit Constants.java so that NLOGN = true, ENABLE_DEBUG = false, ENABLE_PREFERRED_KD_NODE = true, ENABLE_PREFERRED_AVL_NODE = true, ENABLE_1TO3 = true, ENABLE_INSERTION_REBALANCE = false, ENABLE_DELETION_REBALANCE = false, ENABLE_TUPLE_COPY = false, ENABLE_SPARSE_INSERTION = false, MULTI_THREAD_CUTOFF = 16384
read -s -p "Enter Password for sudo: " sudoPW
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/log/2801k/i7.14.2801k.3d.nlogn.preferred.1to3.z8.c16k.1t.100i.cache.txt taskset -c 0 java TestKdTreeLogarithmic -d 3 -n 2801418 -m 1000 -g -j -z 8 -i 100 > ./test/log/2801k/i7.14.2801k.3d.nlogn.preferred.1to3.z8.c16k.1t.100i.txt
