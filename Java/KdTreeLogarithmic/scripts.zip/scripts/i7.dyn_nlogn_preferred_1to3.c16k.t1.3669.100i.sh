#! /bin/bash
# Edit Constants.java so that NLOGN = true, ENABLE_DEBUG = false, ENABLE_PREFERRED_KD_NODE = true, ENABLE_PREFERRED_AVL_NODE = true, ENABLE_1TO3 = true, ENABLE_INSERTION_REBALANCE = true, ENABLE_DELETION_REBALANCE = true, ENABLE_TUPLE_COPY = false, ENABLE_SPARSE_INSERTION = false, MULTI_THREAD_CUTOFF = 16384
read -s -p "Enter Password for sudo: " sudoPW
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/dyn/3669k/i7.14.3669k.3d.nlogn.preferred.1to3.c16k.1t.100i.cache.txt taskset -c 0 java TestKdTreeDynamic -d 3 -n 3668582 -m 1000 -g -j -i 100 > ./test/dyn/3669k/i7.14.3669k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
