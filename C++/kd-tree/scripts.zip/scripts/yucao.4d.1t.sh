#! /bin/bash
read -s -p "Enter Password for sudo: " sudoPW
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/32k/i7.14.32k.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 32768 -d 4 -t 1 > ./test/yucao/32k/i7.14.32k.4d.1t.10i.txt
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/64k/i7.14.64k.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 65536 -d 4 -t 1 > ./test/yucao/64k/i7.14.64k.4d.1t.10i.txt
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/128k/i7.14.128k.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 131072 -d 4 -t 1 > ./test/yucao/128k/i7.14.128k.4d.1t.10i.txt
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/256k/i7.14.256k.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 262144 -d 4 -t 1 > ./test/yucao/256k/i7.14.256k.4d.1t.10i.txt
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/512k/i7.14.512k.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 524288 -d 4 -t 1 > ./test/yucao/512k/i7.14.512k.4d.1t.10i.txt
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/1m/i7.14.1m.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 1048576 -d 4 -t 1 > ./test/yucao/1m/i7.14.1m.4d.1t.10i.txt
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/2m/i7.14.2m.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 2097152 -d 4 -t 1 > ./test/yucao/2m/i7.14.2m.4d.1t.10i.txt
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/4m/i7.14.4m.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 4194304 -d 4 -t 1 > ./test/yucao/4m/i7.14.4m.4d.1t.10i.txt
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/8m/i7.14.8m.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 8388608 -d 4 -t 1 > ./test/yucao/8m/i7.14.8m.4d.1t.10i.txt
echo $sudoPW | sudo -S time perf stat -e LLC-load-misses,cache-misses,cache-references -o ./test/yucao/16m/i7.14.16m.4d.1t.10i.cache.txt taskset -c 0 ./a.yucao.out -i 10 -n 16777216 -d 4 -t 1 > ./test/yucao/16m/i7.14.16m.4d.1t.10i.txt
