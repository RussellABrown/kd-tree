The test_kdtree.cpp file was compiled via:

g++ -std=c++11 -O3 -D PREALLOCATE -D NLOGN -D INDEX_CUTOFF=16384 -D BIDIRECTIONAL_PARTITION test_kdtree.cpp
