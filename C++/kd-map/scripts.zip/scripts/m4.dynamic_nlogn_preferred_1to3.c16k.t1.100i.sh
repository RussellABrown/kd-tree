#! /bin/bash
# Create a.out by compiling with -D NLOGN -D ENABLE_PREFERRED_TEST -D ENABLE_1TO3 -D MULTI_THREAD_CUTOFF=16384
time ./a.out -d 3 -n 62746 -b -i 100 > ./test/dynamic/63k/m4.63k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 118650 -b -i 100 > ./test/dynamic/119k/m4.119k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 172455 -b -i 100 > ./test/dynamic/172k/m4.172k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 224979 -b -i 100 > ./test/dynamic/225k/m4.225k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 276589 -b -i 100 > ./test/dynamic/277k/m4.277k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 327491 -b -i 100 > ./test/dynamic/327k/m4.327k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 377820 -b -i 100 > ./test/dynamic/378k/m4.378k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 427667 -b -i 100 > ./test/dynamic/428k/m4.428k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 477101 -b -i 100 > ./test/dynamic/477k/m4.477k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 526172 -b -i 100 > ./test/dynamic/526k/m4.526k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 1003201 -b -i 100 > ./test/dynamic/1003k/m4.1003k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 1464689 -b -i 100 > ./test/dynamic/1465k/m4.1465k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 1916615 -b -i 100 > ./test/dynamic/1917k/m4.1917k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 2361679 -b -i 100 > ./test/dynamic/2362k/m4.2362k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 2801418 -b -i 100 > ./test/dynamic/2801k/m4.2801k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 3236823 -b -i 100 > ./test/dynamic/3237k/m4.3237k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 3668582 -b -i 100 > ./test/dynamic/3669k/m4.3669k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 4097202 -b -i 100 > ./test/dynamic/4097k/m4.4097k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
time ./a.out -d 3 -n 4523071 -b -i 100 > ./test/dynamic/4523k/m4.4523k.3d.nlogn.preferred.1to3.c16k.1t.100i.txt
